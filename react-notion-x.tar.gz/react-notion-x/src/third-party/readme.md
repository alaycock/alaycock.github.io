# react-notion-x third-party modules

All of the modules in this folder contain large, optional, third-party dependencies.

To guarantee a minimal bundle size, they must be imported separately from the rest of `react-notion-x`.

## License

MIT © [Travis Fischer](https://transitivebullsh.it)

Support my OSS work by <a href="https://twitter.com/transitive_bs">following me on twitter <img src="https://storage.googleapis.com/saasify-assets/twitter-logo.svg" alt="twitter" height="24px" align="center"></a>
