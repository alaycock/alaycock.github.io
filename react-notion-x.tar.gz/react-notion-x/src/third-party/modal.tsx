import Modal from 'react-modal'

Modal.setAppElement('.notion-frame')

export { default as Modal } from 'react-modal'
