# react-notion-x

## 7.2.5

### Patch Changes

- Fix images
- Updated dependencies
  - notion-types@7.1.5
  - notion-utils@7.1.5

## 7.2.4

### Patch Changes

- Minor fixes
- Updated dependencies
  - notion-types@7.1.4
  - notion-utils@7.1.4

## 7.2.3

### Patch Changes

- twitter utils
- Updated dependencies
  - notion-types@7.1.3
  - notion-utils@7.1.3

## 7.2.2

### Patch Changes

- Add getPageTweets util
- Updated dependencies
  - notion-types@7.1.2
  - notion-utils@7.1.2

## 7.2.1

### Patch Changes

- Fix build
- Updated dependencies
  - notion-types@7.1.1
  - notion-utils@7.1.1

## 7.2.0

### Minor Changes

- Move some utils into notion-utils

### Patch Changes

- Updated dependencies
  - notion-types@7.1.0
  - notion-utils@7.1.0

## 7.1.0

### Minor Changes

- Move react-pdf to be optional

## 7.0.1

### Major Changes

- 3c4b572: Maintenance update

### Patch Changes

- bac28e2: Minor fixes
- Updated dependencies [3c4b572]
  - notion-types@7.0.1
  - notion-utils@7.0.1
